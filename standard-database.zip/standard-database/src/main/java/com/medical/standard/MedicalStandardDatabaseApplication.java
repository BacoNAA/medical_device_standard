package com.medical.standard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalStandardDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalStandardDatabaseApplication.class, args);
	}

}
