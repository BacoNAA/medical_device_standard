package com.medical.standard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalStandardDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
